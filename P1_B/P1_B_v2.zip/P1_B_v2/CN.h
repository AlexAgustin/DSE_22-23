
// declaracion de las funciones relacionadas con modulo CN
// que se usan en otros modulos

void inic_CN();

