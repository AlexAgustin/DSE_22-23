// Exporta variables y funciones invocadas en otros modulos
extern int inicializar_crono; //flag que indica si se ha de incializar el cronometro

// declaracion de las funciones relacionadas con los temporizadores
// que se usan en otros modulos
void inic_Timer7 ();
void cronometro();
void inic_crono();
