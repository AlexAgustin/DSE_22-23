// Exporta funciones invocadas en otros modulos

// funciones
void inic_Timer9(unsigned long ciclos);
void delay_ms(unsigned int ms);
void delay_us(unsigned int us);
