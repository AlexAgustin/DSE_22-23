/* Funciones para trabajar con el modulo UART2_RS232.h
================================================

Autores: Alex y Amanda
Fecha: Febrero 2023
*/

// funciones que se utilizan desde otros modulos
void inic_UART2 ();



