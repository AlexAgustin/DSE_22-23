
// declaracion de las funciones auxiliares
// que se usan en otros modulos

void conversion_tiempo (unsigned char * dir, unsigned int val);
