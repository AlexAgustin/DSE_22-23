
// declaracion de las funciones relacionadas con el modulo CN
// que se usan en otros modulos

void inic_CN();

