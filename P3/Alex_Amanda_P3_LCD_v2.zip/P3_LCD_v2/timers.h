// Exporta una variable y funciones invocadas en otros modulos
//Flag para inicializar el cronometro
extern int inicializar_crono;
// declaracion de las funciones relacionadas con los temporizadores
// que se usan en otros modulos

void inic_Timer9(unsigned long ciclos);
void Delay_ms(unsigned int ms);
void Delay_us(unsigned int us);
void inic_Timer7 ();
void inic_crono();
void cronometro();
void inic_Timer5 ();