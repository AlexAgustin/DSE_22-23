
// Variables y funciones exportadas para utilizarlas desde otros modulos

// VARIABLES
//=========================================================
extern unsigned int DUTY_MIN;
extern unsigned int DUTY_MAX;
extern unsigned int flag_DUTY;
extern unsigned int flag_Duty_LCD;

// FUNCIONES
//=========================================================
//void inic_OC1 ();
void visualizar_Duty();
void inic_PWM();
